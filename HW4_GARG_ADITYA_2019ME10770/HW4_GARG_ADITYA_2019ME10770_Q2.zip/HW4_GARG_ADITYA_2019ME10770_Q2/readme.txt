Variables: X (training input), t (training target), Xgrid (to use used for prediction/plot), alpha (variance of prior = 1/lambda)
----------------------------------------------------------------------------------------------------------------------------------

you need to install the logistic regression module using the following command : pip install bayes_logistic ; for more details read this link - https://pypi.org/project/bayes_logistic/


the folder consists of : 

1) plots for the parts c and d 
2) a jupyter notebook that has the code and theory for parts a, b, c, d
3) a read-me file with all the instructions and requirements for running the code