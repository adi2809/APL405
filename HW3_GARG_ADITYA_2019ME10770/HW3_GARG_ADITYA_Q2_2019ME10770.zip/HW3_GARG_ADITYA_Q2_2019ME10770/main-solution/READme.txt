as we werent provided with the python code for the fixed point iteration method, it was very hard to implement the method hence we have used pyMC3 for probabilistic modelling of the problem using the priors on the mean and the precision of the beta distribution as the last resort. polya-fastfit is now even not working in matlab (outdated) the code from eric-suh's library isnt going to work for our purpose.

i have mailed souvik sir regarding this problem, kindly discuss with him if any disputes arise while checking the problem.Regards, 



Edits : 

I have used the code provided to us in Matlab, attached a figure that represents the fixed point theta ; you need to run the polyafit file in MATLAB once followed by the code as in figure to generate the results. Kindly check the problem.

Aditya Garg (2019ME10770)