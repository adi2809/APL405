Variables: Xtrain (training input), Xtest (test input), y (training output)

Aditional variables for student's t: dof 0.6296, sigma2 = 0.0688 